Thanks you for downloading the Vehicles asset pack v1

These assets were created to aid programmers and game developers and for me to meet new people.

the objects are in OBJ+MTL and Blender format.
The blender files are saved with cycles materials
The OBJ files have their materials info in the mtl with linked textures

All the files come AS-IS. 
If there are problems with them you can mention them to me but I cannot guarantee that I will fix them.

Feel free to make donations on my paypal so I can continue to make assets :)

If you have questions or like to do a request, don't hesitate to contact me:

Twitter:   @eracoon
Facebook:  facebook.com/racoon-media

E-mail:    eracoon@gmail.com (also paypal adress)
Website:   www.racoon-media.nl

Have fun :)

